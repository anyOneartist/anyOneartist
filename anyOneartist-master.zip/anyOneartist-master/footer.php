<footer>

        <ul style="font-size: 20px; color: #ffffff">
            <span><a href="index.php"><li class="glyphicon glyphicon-home"></li></a></span>
            <span class="underBar"><li class="glyphicon glyphicon-th-list"></li></span>
            <span><a href="original_ver3.php"><li class="glyphicon glyphicon-facetime-video"></li></a></span>
            <span><li class="glyphicon glyphicon-cog"></li></span>
            <span><a href="account-movie.php"><li class="glyphicon glyphicon-user"></li></a></span>
        </ul>
</footer>
